#ifndef PRACTICA_HH
#define PRACTICA_HH

#include <iostream>
#include <vector>
#include <list>
#include <set>
#include <limits>
#include <algorithm>
#include <utility>
using namespace std;

typedef vector<vector<int>> Graph;
typedef vector<int> Pids;
typedef vector < pair<int, int> > V;

/**
 * @brief 
 * 
 */
class Practica{
private:
    Graph G;
    set<int> pids;
    
    //int min_pids(Pids state);
    //void in_out(Pids& state, int pos);
    bool is_pids(set<int> state);
    list<set<int>> generate_successors(set<int> state);
    set<int>  best_successor(list<set<int>> successors);
    bool can_add(set<int> state, int pos);
    bool can_remove(set<int> state, int pos);
    void add_vertex(set<int>& state, int pos);
    void remove_vertex(set<int>& state, int pos);
    Pids copy_vector(Pids D, int i);
    
public:
    Practica();
    Practica(Graph g);
    void llegir_graf(int n, int m);
    Graph obtenir_graf();
    Pids llegir_conjunt();
    bool es_cjt_dominador_inf_pos(Pids D);
    bool es_minimal(Pids D);
    void trobar_conjunt(V P, Pids& D);
    V grados_grafo();
    void search(set<int> p);
    void print_goal();

};
#endif

