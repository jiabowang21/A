#include "practica.hh"

bool sortPairs(const pair<int, int> &x, const pair<int, int> &y) {
	return x.second > y.second;
}

int main(){
    int n, m;		        //n -> número de vértices y m número de aristas
    cin >> n >> m;
    //Grafo G
    Practica p;
    p.llegir_graf(n, m); //representació amb una llista d'adjacència
    V grau = p.grados_grafo();
    sort(grau.begin(), grau.end(), sortPairs);
    for (int i = 0; i < grau.size(); ++i) {
    	cout << "vertex " << grau[i].first << " grau " << grau[i].second << endl;
    }
    Pids D;
    p.trobar_conjunt(grau, D);
    for (int j = 0; j < D.size(); ++j) {
    	cout << D[j] << " ";
    }
    cout << endl;
}