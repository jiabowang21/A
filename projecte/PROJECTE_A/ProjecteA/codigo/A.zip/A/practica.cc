#include "practica.hh"

/*bool operator <(const Pids& a, const Pids& b){
    int x,y;
    x = y = 0;
    for(int i = 0; i < a.size(); ++i){
        if(a[i] == 1) ++x;
        if(b[i] == 1) ++y;
    }
    if(x == y) return a < b;
    else return x < y;
}*/

/*bool compare2(const Pids& a, const Pids& b){
    int x,y;
    x = y = 0;
    for(int i = 0; i < a.size(); ++i){
        if(a[i] == 1) ++x;
        if(b[i] == 1) ++y;
    }
    if(x == y) return a < b;
    else return x < y;
    
}*/


/*int Practica::min_pids(Pids state){
    int res = 0;
    for(int i = 0; i < state.size(); ++i){
        if(state[i] == 1) ++res;
    }
    return res;
}*/

bool Practica::is_pids(set<int> state){
    for(int i = 0; i < this->G.size(); ++i){
        int count = 0;
        for(int j = 0; j < this->G[i].size(); ++j){
            bool found = state.find(this->G[i][j]) != state.end();
            
            if(found) ++count;
        }
        if((float(count)/this->G[i].size()) < 0.5) return false; 
    }
    return true;
}

bool Practica::can_add(set<int> state, int pos){
    bool condition1 = state.find(pos) == state.end();
    if(condition1){
        state.insert(pos);
        bool condition2 = is_pids(state);
        return condition1 and condition2;
    }
    return false;
}

bool Practica::can_remove(set<int> state, int pos){
    bool condition1 = state.find(pos) != state.end();
    if(condition1){
        state.erase(pos);
        bool condition2 = is_pids(state);
        return condition1 and condition2;
    }
    return false;
}

/*void Practica::in_out(Pids& state, int pos){
    state[pos] = state[pos] ^ 1;  
}*/

void Practica::add_vertex(set<int>& state, int pos){
    state.insert(pos);
}

void Practica::remove_vertex(set<int>& state, int pos){
    state.erase(pos);
}

list<set<int>> Practica::generate_successors(set<int> state){
    list<set<int>> res;
    list<set<int>>::iterator it = res.begin();
    for(int i = 0; i < this->G.size(); ++i){
        set<int> aux = state;
        if(can_add(aux, i)){
            add_vertex(aux, i);
            res.insert(it, aux);
        }
        if(can_remove(aux, i)){
            remove_vertex(aux, i);
            res.insert(it, aux);
        }
    }
    return res;
}

set<int> Practica::best_successor(list<set<int>> successors){
    list<set<int>>::iterator it;
    successors.sort([&](const set<int>& pids1, const set<int>& pids2)
    {
      if(pids1.size() == pids2.size()) return pids1 < pids2;
      return pids1.size() < pids2.size();
    });
    it = successors.begin();
    return *it;

}

Pids Practica::copy_vector(Pids D, int i) {
	Pids aux;
	for (int x = 0; x < D.size(); ++x) {
		if (x != i) {
			aux.push_back(D[x]);
		}
	}
	return aux;
}

Practica::Practica(){
}

Practica::Practica(Graph g){
    this->G = g;
}

void Practica::llegir_graf(int n, int m){
    Graph g = Graph(n);
    int x, y;
    for (int j = 0; j < m; j++) {
        cin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    this->G = g;
}

Graph Practica::obtenir_graf(){
    return this->G;
}

Pids Practica::llegir_conjunt(){
    Pids d;
	int x;
	while (cin >> x) {
		d.push_back(x);
	}
	return d;
}

bool Practica::es_cjt_dominador_inf_pos(Pids D) {
	for (int i = 0; i < this->G.size(); ++i) {
		float contador = 0;
		for (int j = 0; j < this->G[i].size(); ++j) {
			for (int l = 0; l < D.size(); ++l) {
				if (this->G[i][j] == D[l]) ++contador;
			}
		}
		if ((contador/G[i].size()) < 0.5) return false;
	}
	return true;
}

bool Practica::es_minimal(Pids D) {
	for (int i = 0; i < D.size(); ++i) {
		Pids Daux = copy_vector(D, i);
		if (es_cjt_dominador_inf_pos(Daux)) return false;

	}
	return true;
}

void Practica::trobar_conjunt(V P, Pids& D) {
	for (int i = 0; i < P.size(); ++i) {
		D.push_back(P[i].first);
		if (es_cjt_dominador_inf_pos(D)) {
			return;
		}
	}
}

V Practica::grados_grafo() {
	V res;
	for (int i = 0; i < this->G.size(); ++i) {
		res.push_back(make_pair(i, this->G[i].size()));
	}
	return res;
}


void Practica::search(set<int> p){
    set<int> act = p;
    list<set<int>> successors;
    list<set<int>>::iterator it = successors.begin();
    bool end = false;
    while (not end){
        successors= generate_successors(act);
        set<int> succ = best_successor(successors);
        if(act.size() > succ.size()){
            act = succ;
        }
        else {
            end = true;
        }
    }
    this->pids = act;
}

void Practica::print_goal(){
    bool first = true;
    set<int>::iterator it = this->pids.begin();
    cout << "Conjunt dominador d'influencia positiva:" <<endl;
    cout << "D = {";
    for(it = this->pids.begin(); it != this->pids.end(); ++it){
        if(first){
            cout << *it;
            first = false;
        }
        else {
            cout << ", " << *it;
        }
    }
    cout << "}" <<endl;
}