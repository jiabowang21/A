#include "practica.hh"

bool sortPairs(const pair<int, int> &x, const pair<int, int> &y) {
	return x.second > y.second;
}

int main(){
    /*Graph graph {{1}, {0, 2, 3, 4}, {1}, {1, 4}, {1, 4}};
    Pids pids {true, true, true, true, false};
    set<int> p = {0, 1, 2, 3, 4};
    Practica h {graph};*/
    int n, m;		       
    cin >> n >> m;
    Practica p;
    p.llegir_graf(n, m);

    V grau = p.grados_grafo();
    sort(grau.begin(), grau.end(), sortPairs);

    Pids D;
    p.trobar_conjunt(grau, D);

    set<int>ini(D.begin(), D.end());
    set<int>::iterator it;

    p.search(ini);
    p.print_goal();
}